from psychopy import visual,event,core
import csv
import tkinter as tk
from tkinter.simpledialog import *

window = tk.Tk()
subs_num = askinteger('Subject', prompt='被试序号:', initialvalue=1, maxvalue=120, minvalue=1)
subs_gender = askstring('Subject', prompt='性别', initialvalue='男')##改成中文，加上女性
window.destroy()

# create screen
win = visual.Window(fullscr = True,size = [1280, 720],color = (1.0,1.0,1.0), units = 'norm', monitor = 'testMonitor')
timer=core.Clock()
def display_word(word,gaideword1,gaidword2):
    text_word = visual.TextStim(win,
        text = u'',height = 0.15,pos = (0.0,0.0),color = 'black',
        bold = False,italic = False)
    text_word.text=word
    text_word2 = visual.TextStim(win,
        text = u'',height = 0.1,pos = (-0.5,0.5),color = 'black',
        bold = False,italic = False)
    text_word2.text=gaideword1
    text_word3 = visual.TextStim(win,
        text = u'',height = 0.05,pos = (0.5,0.5),color = 'black',
        bold = False,italic = False)
    text_word3.text=gaidword2
    text_word.draw()
    text_word2.draw()
    text_word3.draw()
    win.flip()

def display_word2(word):
    text_word = visual.TextStim(win,
        text = u'',height = 0.1,pos = (0.0,0.0),color = 'black',
        bold = False,italic = False)
    text_word.text=word
    text_word.draw()
    win.flip()
    key=event.waitKeys(keyList=None)
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)

def display_pic(pic_name):
    pic_path = pic_name
    pic = visual.ImageStim(win, size=None, image = pic_path)
    pic.draw()
    win.flip()
    core.wait(1)

display_word2('下面开始第一阶段测试\n接下来展示的词语是关于的男性和女性的\n看到男性的词语请按J键，女性请按F键\n不用在意对错，会有相关图片提示\n按任意键继续')
core.wait(1)
display_word('hello','yeppy','vivian')
timer.reset()
key=event.waitKeys(keyList=['f','j'])
RT = timer.getTime()
core.wait(1)
win.flip() # blank
core.wait(0.5)
print(RT,subs_num,subs_gender)

