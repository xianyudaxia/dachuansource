import tkinter as tk
from tkinter.simpledialog import *
from psychopy import visual,event,core
import random
import csv
f = open("D:IAT.csv",'w',newline = '')
csv_writer = csv.writer(f)

# collect informaiton
window = tk.Tk()
subs_num = askinteger('Subject', prompt='序号:', initialvalue=1, maxvalue=400, minvalue=1)
subs_gender = askstring('Subject', prompt='性别', initialvalue='male')##改成中文，加上女性
window.destroy()
csv_writer.writerow([subs_num,subs_gender])
csv_writer.writerow(["Trial","stimulus","RightAnswer","Response","RT"])

# create screen
win = visual.Window(fullscr =True,size = [1280, 720],color = (1.0,1.0,1.0), units = 'norm', monitor = 'testMonitor')
win.mouseVisible = False   # hide mouse
timer=core.Clock()         # set timer

def readFile(path):
    f = open(path,encoding="utf-8")
    list_word = []
    list_word = f.read().splitlines() # cut off newline
    f.close()
    return list_word

word_A = readFile("D:\乱玩python\IAT\WORDB.txt")
word_B = readFile("D:\乱玩python\IAT\WORDC.txt")
word_C = readFile("D:\乱玩python\IAT\WORDD.txt")
word_D = readFile("D:\乱玩python\IAT\WORDA.txt")
stimuli_AA = word_A+word_C
stimuli_BB = word_B+word_D
stimuli_CC = word_A+word_D
stimuli_DD = word_B+word_C

# display word
def display_word(word,gaideword1,gaidword2):
    text_word = visual.TextStim(win,
        text = u'',height = 0.15,pos = (0.0,0.0),color = 'black',
        bold = False,italic = False)
    text_word.text=word
    text_word2 = visual.TextStim(win,
        text = u'',height = 0.1,pos = (-0.5,0.5),color = 'red',
        bold = False,italic = False)
    text_word2.text=gaideword1
    text_word3 = visual.TextStim(win,
        text = u'',height = 0.1,pos = (0.5,0.5),color = 'red',
        bold = False,italic = False)
    text_word3.text=gaidword2
    text_word.draw()
    text_word2.draw()
    text_word3.draw()
    win.flip()

def display_word2(word):
    text_word = visual.TextStim(win,
        text = u'',height = 0.1,pos = (0.0,0.0),color = 'black',
        bold = False,italic = False)
    text_word.text=word
    text_word.draw()
    win.flip()
    key=event.waitKeys(keyList=None)
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)

'''
# display image
def display_pic(pic_name):
    pic_path = 'resources/'+pic_name
    pic = visual.ImageStim(win, size=None, image = pic_path)
    pic.draw()
    win.flip()
'''

display_word2('下面我们要进行一项分类任务\n一会电脑的屏幕中央会出现一些词语\n你需要对这些词语分类。\n分类的时候要尽可能快速，但也要少犯错\n一共有五个阶段\n按任意键继续')

#The first part-single practise
display_word2('下面开始第一阶段测试\n接下来展示的词语是关于的男性和女性的\n看到男性的词语请按J键，女性请按F键\n不用在意对错，会有相关图片提示\n按任意键继续')

list_prac =(word_A+word_B)
random.shuffle(list_prac)

for i in range(len(list_prac)):
    gaideword1='属于女性的词语\n按F键'
    gaideword2='属于男性的词语\n按J键'
    display_word('+','','')  # display fixation
    core.wait(0.1) # display for 1 sec

    display_word(list_prac[i],gaideword1,gaideword2)
    key=event.waitKeys(keyList=['f','j'])

    # feedback: response right or wrong
    if word_A.count(list_prac[i])==0:
        press = 'j'
    else:
        press = 'f'
    if press == key[0]:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\正确1.jpg")
    else:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\错误1.jpg")
    pic.draw()
    win.flip()
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)

display_word2('下面开始第二阶段测试\n接下来展示的词语是关于语文和数学的\n看到关于数学的词语请按J键，关于语文的词语请按F键\n不用在意对错，会有相关图片提示\n按任意键继续')
list_prac =(word_C+word_D)
random.shuffle(list_prac)

for i in range(len(list_prac)):
    gaideword1='属于语文的词语\n按F键'
    gaideword2='属于数学的词语\n按J键'
    display_word('+','','')  # display fixation
    core.wait(0.1) # display for 1 sec

    display_word(list_prac[i],gaideword1,gaideword2)
    key=event.waitKeys(keyList=['f','j'])

    # feedback: response right or wrong
    if word_C.count(list_prac[i])==0:
        press = 'j'
    else:
        press = 'f'
    if press == key[0]:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\正确1.jpg")
    else:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\错误1.jpg")
    pic.draw()
    win.flip()
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)

#test start!
display_word2('下面开始第三阶段正式测试\n接下来展示的词语是前两个阶段的整合\n看到关于数学和男性的词语请按J键\n关于语文和女性的词语请按F键\n按任意键继续')
stimuli_prac = (stimuli_AA + stimuli_BB)*2
random.shuffle(stimuli_prac)

for i in range(len(stimuli_prac)):
    gaideword1='属于女性和语文的词语\n按F键'
    gaideword2='属于男性和数学的词语\n按J键'
    display_word('+','','')  # display fixation
    core.wait(0.1) # display for 1 sec
    
    stimulus = stimuli_prac[i]
    display_word(stimulus,gaideword1,gaideword2)
    timer.reset()
    key=event.waitKeys(keyList=['f','j'])
    RT = timer.getTime()
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)
    if word_A.count(stimulus)!=0:   
        press = 'f'
    elif word_B.count(stimulus)!=0:
        press = 'j'
    elif word_C.count(stimulus)!=0:
        press = 'f'
    elif word_D.count(stimulus)!=0:
        press = 'j'
    list_trial=[i+1,stimulus,press,key[0],RT]
    csv_writer.writerow(list_trial)


#The second part-single practise
list_prac =(word_A+word_B)
random.shuffle(list_prac)
display_word2('下面开始第四阶段测试\n交换测试！！！\n接下来展示的词语是关于的男性和女性的\n看到女性的词语请按J键，男性请按F键\n不用在意对错，会有相关图片提示\n按任意键继续')
for i in range(len(list_prac)):
    gaideword1='属于男性的词语\n按F键'
    gaideword2='属于女性的词语\n按J键'
    display_word('+','','')  # display fixation
    core.wait(0.1) # display for 1 sec

    display_word(list_prac[i],gaideword1,gaideword2)
    key=event.waitKeys(keyList=['f','j'])

    # feedback: response right or wrong
    if word_A.count(list_prac[i])==0:
        press = 'f'
    else:
        press = 'j'
    if press == key[0]:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\正确1.jpg")
    else:
        pic = visual.ImageStim(win, size=None, image = "D:\乱玩python\IAT\错误1.jpg")
    pic.draw()
    win.flip()
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)

#test start!
stimuli_prac = (stimuli_AA + stimuli_BB)*2
random.shuffle(stimuli_prac)
display_word2('下面开始第五阶段正式测试\n接下来展示的词语是前两个阶段的整合\n看到关于数学和女性的词语请按J键\n关于语文和男性的词语请按F键\n按任意键继续')
for i in range(len(stimuli_prac)):
    gaideword1='属于男性和语文的词语\n按F键'
    gaideword2='属于女性和数学的词语\n按J键'
    display_word('+','','')  # display fixation
    core.wait(0.1) # display for 1 sec
    
    stimulus = stimuli_prac[i]
    display_word(stimulus,gaideword1,gaideword2)
    timer.reset()
    key=event.waitKeys(keyList=['f','j'])
    RT = timer.getTime()
    core.wait(1)
    win.flip() # blank
    core.wait(0.5)
    if word_A.count(stimulus)!=0:   
        press = 'j'
    elif word_B.count(stimulus)!=0:
        press = 'f'
    elif word_C.count(stimulus)!=0:
        press = 'f'
    elif word_D.count(stimulus)!=0:
        press = 'j'
    list_trial=[i+1,stimulus,press,key[0],RT]
    csv_writer.writerow(list_trial)

f.close()

##打包指令，输入终端
#Pyinstaller -F -w -i xiongmaotou.ico IAT.py